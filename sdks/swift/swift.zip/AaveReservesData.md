# AaveReservesData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentAtokenBalance** | **String** |  | 
**currentBorrowBalance** | **String** |  | 
**principalBorrowBalance** | **String** |  | 
**borrowRateMode** | **String** |  | 
**borrowRate** | **String** |  | 
**liquidityRate** | **String** |  | 
**originationFee** | **String** |  | 
**variableBorrowIndex** | **String** |  | 
**lastUpdateTimestamp** | **String** |  | 
**usageAsCollateralEnabled** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


