# AaveReservesAPIResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **Bool** |  | 
**message** | **String** |  | 
**body** | [**InputBody**](InputBody.md) |  | [optional] 
**address** | **String** |  | [optional] 
**data** | [**AaveReservesData**](AaveReservesData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


