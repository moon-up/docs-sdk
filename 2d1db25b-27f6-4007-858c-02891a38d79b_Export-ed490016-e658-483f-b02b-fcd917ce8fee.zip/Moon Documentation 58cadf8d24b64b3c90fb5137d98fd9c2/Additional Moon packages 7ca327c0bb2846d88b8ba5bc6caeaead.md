# Additional Moon packages

For tools to help build and customize a MoonWallet UI, we recommend using these **@moonup** packages:

- **@moonup/ethers:** for smooth interaction with the Ethereum Blockchain
    
    [Moon Ethers](Additional%20Moon%20packages%207ca327c0bb2846d88b8ba5bc6caeaead/Moon%20Ethers%20f381fbf881c647e1aab3d43fb4ad0600.md)
    
- **@moonup/wagmi:** for making common interactions with the Ethereum Blockchain in React-based dApps even simpler
    
    [Moon Wagmi](Additional%20Moon%20packages%207ca327c0bb2846d88b8ba5bc6caeaead/Moon%20Wagmi%203d44fd4699594c2397129482dc52589f.md)