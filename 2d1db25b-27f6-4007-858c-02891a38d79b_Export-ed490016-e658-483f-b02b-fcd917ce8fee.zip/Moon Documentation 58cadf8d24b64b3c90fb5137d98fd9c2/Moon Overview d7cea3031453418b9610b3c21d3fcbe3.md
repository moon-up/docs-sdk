# Moon Overview

<aside>
🌙 Moon is a highly composable wallet and authentication infrastructure designed to simplify user-friendly, AI-compatible dApp development.

</aside>

[What Can Moon Do?](Moon%20Overview%20d7cea3031453418b9610b3c21d3fcbe3/What%20Can%20Moon%20Do%2074d061268b68403dbb078374c7035be4.md)

[What are Moon’s Use Cases?](Moon%20Overview%20d7cea3031453418b9610b3c21d3fcbe3/What%20are%20Moon%E2%80%99s%20Use%20Cases%2045f6bdf4020641e4a8df0c81e5fdc71b.md)

[What Features Come with Moon?](Moon%20Overview%20d7cea3031453418b9610b3c21d3fcbe3/What%20Features%20Come%20with%20Moon%200de8a91f3e534ba58c43b69528fcb84b.md)

[What Skills are Needed for Moon](Moon%20Overview%20d7cea3031453418b9610b3c21d3fcbe3/What%20Skills%20are%20Needed%20for%20Moon%20100d898cb9eb417b92d3caab8c602b4c.md)